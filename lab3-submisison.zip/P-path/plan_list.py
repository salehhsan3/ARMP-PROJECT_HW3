['open', 'homeTocube1_path.npy', 'close', 'cube1Tocube1_goal_path.npy', 'open', 'cube1_goalTocube2_approach_path.npy', 'close',
 'cube2Tocube2_goal_path.npy', 'open', 'cube2_goalTocube3_approach_path.npy', 'close', 'cube3Tocube3_goal_path.npy', 'open',
 'cube3_goalTocube4_approach_path.npy', 'close', 'cube4Tocube4_goal_path.npy', 'open', 'cube4_goalTocube5_approach_path.npy',
 'close', 'cube5Tocube5_goal_path.npy', 'open', 'cube5_goalTocube6_approach_path.npy', 'close', 'cube6Tocube6_goal_path.npy', 'open'
]